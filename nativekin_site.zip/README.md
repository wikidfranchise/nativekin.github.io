# NativeKin

A public syllabus and dynamic repository of Native American history, power structures, legal fights, and cultural voices.